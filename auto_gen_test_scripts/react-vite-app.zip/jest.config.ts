import type { Config } from '@jest/types';

const config: Config.InitialOptions = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  collectCoverage: true,
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov'],
  setupFilesAfterEnv: ['./jest.setup.ts'], // Point to jest.setup.ts
  moduleFileExtensions: ['js', 'jsx', 'ts', 'tsx'],
};

export default config;
