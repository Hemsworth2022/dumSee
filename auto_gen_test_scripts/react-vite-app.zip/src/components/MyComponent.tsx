interface MyComponentProps {
    name: string;
    age: number;
  }
  
  const MyComponent: React.FC<MyComponentProps> = ({ name, age }) => {
    const handleClick = () => {
      console.log('Button clicked');
    };
  
    return (
      <div onClick={handleClick}>
        <p >{name}</p>
        {age && <span >{age}</span>}
      </div>
    );
  };
  export default MyComponent;
  