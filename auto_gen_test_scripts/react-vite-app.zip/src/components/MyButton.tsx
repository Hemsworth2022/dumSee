// src/components/MyButton.tsx
import React from 'react';

interface MyButtonProps {
  name: string;
}

const MyButton: React.FC<MyButtonProps> = ({ name }) => {
  const handleClick = () => {
    console.log('Button clicked');
  };

  return (
    <div>
      <h2>Hello, {name || 'world'}!</h2>
      <button onClick={handleClick}>Click Me</button>
    </div>
  );
};

export default MyButton;
