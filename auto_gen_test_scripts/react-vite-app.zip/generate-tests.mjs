import fs from 'fs';
import path from 'path';
import { parse } from '@babel/parser';
import traverseModule from '@babel/traverse'; // Import the module
const traverse = traverseModule.default; // Access the default export

// Get the directory containing components
const componentsDir = path.join(process.cwd(), 'src', 'components');

// Read all component files in the directory
const componentFiles = fs.readdirSync(componentsDir).filter((file) => file.endsWith('.tsx') || file.endsWith('.jsx'));

// Helper function to generate mock values for prop types
function getMockValue(type, propName) {
  if (propName.startsWith('on') && typeof type === 'string') {
    // Handle event handler props like onClick, onChange, etc.
    return `{() => { console.log('${propName} called'); }}`;
  }
  switch (type) {
    case 'string': return '"Test value"';
    case 'number': return '42';
    case 'boolean': return 'true';
    case 'function': return '() => {}';
    case 'array': return '[]';
    case 'object': return '{}';
    default: return 'undefined';
  }
}

// Parse a component file
function parseComponent(filePath) {
  const fileContent = fs.readFileSync(filePath, 'utf-8');
  const ast = parse(fileContent, {
    sourceType: 'module',
    plugins: ['jsx', 'typescript'],
  });

  const props = [];
  const functions = [];
  const htmlTags = new Set();
  const state = [];
  const hooks = new Set();

  // Traverse the AST
  traverse(ast, {
    VariableDeclarator(path) {
      // Find function components
      if (path.node.id.name && path.node.init?.type === 'ArrowFunctionExpression') {
        functions.push(path.node.id.name);
      }
    },
    FunctionDeclaration(path) {
      // Find regular functions
      functions.push(path.node.id.name);
    },
    JSXOpeningElement(path) {
      // Find JSX tags and props
      const tagName = path.node.name.name;
      htmlTags.add(tagName);

      path.node.attributes.forEach((attr) => {
        if (attr.type === 'JSXAttribute') {
          const propName = attr.name.name;
          const isRequired = !attr.optional;
          props.push({ name: propName, type: 'string', isRequired });
        }
      });
    },
    CallExpression(path) {
      if (path.node.callee.name === 'useState') {
        const stateName = path.node.arguments[0]?.name;
        if (stateName) {
          state.push(stateName);
        }
      }

      // Capture hooks such as useEffect, useMemo, useCallback
      if (path.node.callee.name && path.node.callee.name.startsWith('use')) {
        hooks.add(path.node.callee.name);
      }
    },
  });

  return { props, functions, htmlTags: [...htmlTags], state, hooks: [...hooks] };
}

// Generate test code
function generateTest(componentName, props, functions, htmlTags, state, hooks) {
  let testCode = `
import { render, screen } from '@testing-library/react';
import ${componentName} from '../${componentName}';

describe('${componentName}', () => {
  test('renders the component', () => {
    render(<${componentName} `;
    
  // Add mock props
  props.forEach(({ name, type, isRequired }) => {
    testCode += `${name}=${getMockValue(type, name)} `;
  });

  testCode += `/>);
    expect(screen.getByTestId('${componentName.toLowerCase()}')).toBeInTheDocument();
  });
  
  // Test for HTML tags
  test('renders correct HTML structure', () => {
    render(<${componentName} `;
    
    // Add only required props
    props.forEach(({ name, type, isRequired }) => {
      if (isRequired) {
        testCode += `${name}=${getMockValue(type, name)} `;
      }
    });
    
    testCode += `/>);
  `;

  htmlTags.forEach((tag) => {
    testCode += `
    expect(screen.getByRole('${tag}')).toBeInTheDocument();`;
  });

  testCode += `
  });
  
  // Test for functions
  ${functions.map((fn) => `
  test('${fn} function is called correctly', () => {
    // Mock and test ${fn}
  });`).join('\n')}

  // Test for state and hooks
  ${state.length > 0 ? `
  test('manages state correctly', () => {
    const { getByTestId } = render(<${componentName} />);
    // Test state initialization and updates
  });` : ''}
  
  ${hooks.length > 0 ? `
  test('executes hooks correctly', () => {
    // Test hooks: ${hooks.join(', ')}
  });` : ''}
});
`;

  return testCode;
}

// Process all component files
componentFiles.forEach((file) => {
  const filePath = path.join(componentsDir, file);
  const componentName = path.basename(file, path.extname(file));
  const { props, functions, htmlTags, state, hooks } = parseComponent(filePath);

  const testCode = generateTest(componentName, props, functions, htmlTags, state, hooks);

  // Write test file
  const testFilePath = path.join(componentsDir, 'tests', `${componentName}.test.tsx`);
  fs.writeFileSync(testFilePath, testCode, 'utf-8');
  console.log(`Generated test file for ${componentName}`);
});
