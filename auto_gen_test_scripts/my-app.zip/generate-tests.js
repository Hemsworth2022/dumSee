const fs = require('fs');
const path = require('path');
const recast = require('recast');

const generateTests = (componentPath) => {
  if (!fs.existsSync(componentPath)) {
    console.error(`Component file not found at: ${componentPath}`);
    process.exit(1);
  }

  const componentCode = fs.readFileSync(componentPath, 'utf-8');
  const parsedCode = recast.parse(componentCode);

  let htmlTags = [];
  let functions = [];
  let apiCalls = [];
  let props = [];
  let hasStoreInteraction = false;

  recast.visit(parsedCode, {
    visitJSXElement(path) {
      const tagName = path.node.openingElement.name.name;
      if (tagName) htmlTags.push(tagName);
      this.traverse(path);
    },
    visitFunctionDeclaration(path) {
      functions.push(path.node.id.name);
      this.traverse(path);
    },
    visitCallExpression(path) {
      const callee = path.node.callee;
      if (callee.object && callee.object.name === 'axios') {
        apiCalls.push(recast.print(path).code);
      }
      if (
        callee.name === 'useSelector' ||
        callee.name === 'useDispatch' ||
        callee.name === 'useContext'
      ) {
        hasStoreInteraction = true;
      }
      this.traverse(path);
    },
    visitVariableDeclarator(path) {
      if (path.node.id.type === 'ObjectPattern') {
        props.push(...path.node.id.properties.map((prop) => prop.key.name));
      }
      this.traverse(path);
    },
  });

  // Remove duplicates
  htmlTags = [...new Set(htmlTags)];
  functions = [...new Set(functions)];
  apiCalls = [...new Set(apiCalls)];
  props = [...new Set(props)];

  // Generate test cases
  const testCases = [];
  
  // HTML tags validation
  htmlTags.forEach((tag) => {
    testCases.push(`
test('renders <${tag}> tag correctly', () => {
  render(<Component />);
  expect(screen.getByRole('${tag === 'button' ? 'button' : 'generic'}')).toBeInTheDocument();
});
    `);
  });

  // Function validation
  functions.forEach((func) => {
    testCases.push(`
test('validates ${func} function', () => {
  const result = ${func}(); // Adjust the arguments if needed
  expect(result).toBeDefined();
});
    `);
  });

  // Props validation
  props.forEach((prop) => {
    testCases.push(`
test('validates ${prop} prop', () => {
  render(<Component ${prop}="testValue" />);
  // Add assertions for the prop behavior
});
    `);
  });

  // Store interaction validation
  if (hasStoreInteraction) {
    testCases.push(`
jest.mock('react-redux', () => ({
  useSelector: jest.fn(),
  useDispatch: jest.fn(),
}));

test('validates store interactions', () => {
  const mockDispatch = jest.fn();
  useDispatch.mockReturnValue(mockDispatch);
  useSelector.mockReturnValue({ key: 'value' }); // Mock store state
  
  render(<Component />);
  expect(mockDispatch).toHaveBeenCalled(); // Validate actions dispatched
});
    `);
  }

  // API calls validation
  apiCalls.forEach((api) => {
    testCases.push(`
jest.mock('axios');
test('validates API call: ${api}', async () => {
  axios.get.mockResolvedValueOnce({ data: {} });
  render(<Component />);
  await waitFor(() => expect(axios.get).toHaveBeenCalledWith(/* API endpoint */));
});
    `);
  });

  // Write test file
  const testFileContent = `
import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import axios from 'axios';
import { useSelector, useDispatch } from 'react-redux';
import Component from './${path.basename(componentPath, '.js')}';

${testCases.join('\n')}
  `;

  const testFilePath = path.join(path.dirname(componentPath), `${path.basename(componentPath, '.js')}.test.js`);
  fs.writeFileSync(testFilePath, testFileContent.trim());
  console.log(`Test file generated: ${testFilePath}`);
};

// CLI Input
const componentPath = process.argv[2];
if (!componentPath) {
  console.error('Please provide the path to the component file.');
  process.exit(1);
}

generateTests(path.resolve(componentPath));
