import React from 'react';
import { useSelector, useDispatch } from 'react-redux';

const MyComponent = ({ title }) => {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.data);

  const handleClick = () => {
    dispatch({ type: 'TEST_ACTION' });
  };

  return (
    <div>
      <h1>{title}</h1>
      <button onClick={handleClick}>Click Me</button>
      {data && <p>{data}</p>}
    </div>
  );
};

export default MyComponent;
