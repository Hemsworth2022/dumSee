import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { useSelector, useDispatch } from 'react-redux';
import Component from './MyComponent';


test('renders <div> tag correctly', () => {
  render(<Component />);
  expect(screen.getByRole('generic')).toBeInTheDocument();
});
    

test('renders <h1> tag correctly', () => {
  render(<Component />);
  expect(screen.getByRole('generic')).toBeInTheDocument();
});
    

test('renders <button> tag correctly', () => {
  render(<Component />);
  expect(screen.getByRole('button')).toBeInTheDocument();
});
    

test('renders <p> tag correctly', () => {
  render(<Component />);
  expect(screen.getByRole('generic')).toBeInTheDocument();
});
    

jest.mock('react-redux', () => ({
  useSelector: jest.fn(),
  useDispatch: jest.fn(),
}));

test('validates store interactions', () => {
  const mockDispatch = jest.fn();
  useDispatch.mockReturnValue(mockDispatch);
  useSelector.mockReturnValue({ key: 'value' }); // Mock store state
  
  render(<Component />);
  expect(mockDispatch).toHaveBeenCalled(); // Validate actions dispatched
});