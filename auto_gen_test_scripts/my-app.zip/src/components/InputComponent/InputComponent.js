import React, { useState } from 'react';

const InputComponent = () => {
  // Declare a state variable to store the input value
  const [inputValue, setInputValue] = useState('');

  // Handle the change in the input field
  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  return (
    <div>
      <h2>Input Value: {inputValue}</h2>
      
      {/* Input field with onChange event */}
      <input
        type="text"
        value={inputValue}
        onChange={handleInputChange}  // Update state on each input change
        placeholder="Type something"
      />
    </div>
  );
};

export default InputComponent;
